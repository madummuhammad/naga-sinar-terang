

<?php $__env->startSection('title'); ?>
In Produksi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>In Produksi</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin-dashboard')); ?>">Dasboard</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('production.index')); ?>">Project Anda</a></li>
            <li class="breadcrumb-item active">In Produksi</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <section class="content">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">In Produksi</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <div class="card-body">
        <div class="d-flex justify-content-end my-2">
          <a data-toggle="modal" data-target="#modalAjukan" class="btn btn-secondary btn-xs ml-2">Ajukan ke QC</a>
          <div class="modal fade" id="modalAjukan">
            <div class="modal-dialog modal-sm modal-dialog-centered">
              <div class="modal-content">
                <form action="<?php echo e(route('production.ajukan')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <div class="modal-header">
                    <h4 class="modal-title">Ajukan Out Produksi</h4>
                    <input type="text" name="project_id" value="<?php echo e($id); ?>" hidden>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <h5>Anda yakin akan mengajukan produksi ke qc?</h5>
                  </div>
                  <div class="modal-footer justify-content-between">
                    <button type="submit" class="btn btn-primary">Ajukan</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('success')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php endif; ?>
        
        <table class="table table-striped table-hover table-sm" id="crudTable">
          <thead>
            <tr>
              <th width="10">No.</th>
              <th>Part Name</th>
              <th>Part No</th>
              <th>Qty In</th>
              <th>Qty Out</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    </div>

  </section>
</div>
<?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="updateModal<?php echo e($item->id); ?>">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <form action="<?php echo e(route('production.update',$item->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>;
        <?php echo csrf_field(); ?>
        <div class="modal-header">
          <h4 class="modal-title">Update Qty Out</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-12 col-lg-12">
              <div class="mb-1">
                <!-- Form Row-->
                <div class="mb-1">
                  <label class="mb-1" for="qty">Qty Out</label>
                  <input type="text" name="project_id" value="<?php echo e($item->project_id); ?>" required hidden>
                  <input class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qty" type="text" value="<?php echo e($item->stock ? $item->stock->qty : 0); ?>"/>
                  <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-script'); ?>
<script>
  var datatable = $('#crudTable').DataTable({
    processing: true,
    serverSide: true,
    ordering: true,
    ajax: {
          url: '<?php echo e(url()->current()); ?>', // Perbaiki tanda seru di sini
        },
        columns: [
        {
          "data": 'DT_RowIndex',
          orderable: false, 
          searchable: false
        },
        { data: 'name', name: 'name' },
        { data: 'part_no', name: 'part_no' },
        { data: 'qty', name: 'qty' },
        { 
          data: function(row) {
            return row.stock ? row.stock.qty : 0;
          },
          name: 'stock.qty',
        },
        { 
          data: 'action', 
          name: 'action',
          orderable: false,
            searchable: false, // Perbaiki typo di sini
            width: '15%'
          },
          ]
        });
      </script>
      <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.1\htdocs\nst\resources\views/pages/admin/production/show.blade.php ENDPATH**/ ?>