

<?php $__env->startSection('main'); ?>
<div class="card-body login-card-body">
  <p class="login-box-msg">Sign in to start your session</p>
  <?php if(session()->has('success')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>    
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session()->has('loginError')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('loginError')); ?>    
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>
<form action="/login" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
    <div class="input-group mb-3">
        <input type="email" class="form-control" name="email" placeholder="Email" required>
        <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
          </div>
      </div>
  </div>
  <div class="input-group mb-3">
      <input type="password" class="form-control" name="password" placeholder="Password"required>
      <div class="input-group-append">
        <div class="input-group-text">
          <span class="fas fa-lock"></span>
      </div>
  </div>
</div>
<div class="row">
  <div class="col-8">
  </div>
  <!-- /.col -->
  <div class="col-4">
    <button type="submit" class="btn btn-primary btn-block">Sign In</button>
</div>
<!-- /.col -->
</div>
</form>

<p class="mb-1">
    <a href="forgot-password.html">Lupa password?</a>
</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.1\htdocs\nst\resources\views/auth/login.blade.php ENDPATH**/ ?>